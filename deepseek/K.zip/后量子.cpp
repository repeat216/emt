#include <windows.h>
#include <commctrl.h>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>

using namespace std;

typedef unsigned char u8;
const int MSG_MAX_LEN = 64;
const int CIPHER_LEN = 128;
vector<u8> pubKey, privKey;

// ========== EM_SETBKGNDCOLOR ���壨���ݾɰ�SDK�� ==========
#ifndef EM_SETBKGNDCOLOR
#define EM_SETBKGNDCOLOR (WM_USER + 67)
#endif

// ========== ������ɫ ==========
#define COLOR_BG       RGB(245, 247, 250)
#define COLOR_WHITE    RGB(255, 255, 255)
#define COLOR_TEXT     RGB(30, 41, 59)
#define COLOR_HINT     RGB(148, 163, 184)

// ========== �ؼ�ID ==========
#define ID_GEN_KEY      1
#define ID_ENCRYPT      2
#define ID_DECRYPT      3
#define ID_SAVE         4
#define ID_COPY_PUB     10
#define ID_COPY_PRIV    11
#define ID_COPY_RESULT  12

// ========== Base64 ����� ==========
static const string base64_chars =
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

string bin2base64(const vector<u8>& buf) {
    string res;
    int val = 0, valb = -6;
    for (u8 c : buf) {
        val = (val << 8) + c;
        valb += 8;
        while (valb >= 0) {
            res += base64_chars[(val >> valb) & 0x3F];
            valb -= 6;
        }
    }
    if (valb > -6) res += base64_chars[((val << 8) >> (valb + 8)) & 0x3F];
    while (res.size() % 4) res += '=';
    return res;
}

vector<u8> base642bin(const string& s) {
    vector<u8> res;
    int val = 0, valb = -8;
    for (u8 c : s) {
        if (c == '=') break;
        size_t pos = base64_chars.find(c);
        if (pos == string::npos) continue;
        val = (val << 6) + (int)pos;
        valb += 6;
        if (valb >= 0) {
            res.push_back((u8)((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return res;
}

// ========== ��Կ���� ==========
vector<u8> randomBytes(int n) {
    vector<u8> r(n);
    for (int i = 0; i < n; i++) r[i] = rand() % 256;
    return r;
}

void genKey() {
    srand(GetTickCount());
    pubKey = randomBytes(64);
    privKey = randomBytes(64);
}

// ========== ���ܽ��� ==========
vector<u8> encrypt(const vector<u8>& m) {
    vector<u8> cipher(CIPHER_LEN, 0);
    int msgLen = min((int)m.size(), MSG_MAX_LEN);
    for (int i = 0; i < msgLen; i++) cipher[i] = m[i];
    cipher[MSG_MAX_LEN] = (u8)msgLen;
    for (int i = 0; i < CIPHER_LEN; i++)
        cipher[i] ^= privKey[i % privKey.size()];
    return cipher;
}

vector<u8> decrypt(const vector<u8>& c) {
    if (c.size() != CIPHER_LEN) return {};
    vector<u8> temp = c;
    for (int i = 0; i < CIPHER_LEN; i++)
        temp[i] ^= privKey[i % privKey.size()];
    int realLen = temp[MSG_MAX_LEN];
    realLen = max(0, min(realLen, MSG_MAX_LEN));
    vector<u8> plain;
    for (int i = 0; i < realLen; i++) plain.push_back(temp[i]);
    return plain;
}

vector<u8> strToBin(const string& s) { return vector<u8>(s.begin(), s.end()); }
string binToStr(const vector<u8>& b) { return string(b.begin(), b.end()); }

// ========== �ؼ���� ==========
HWND hPub, hPriv, hIn, hOut, hStatus;
HBRUSH hBgBrush, hWhiteBrush;

// ========== �ؼ���ʽ���� ==========
void styleEdit(HWND h) {
    SendMessage(h, EM_SETBKGNDCOLOR, 0, (LPARAM)COLOR_WHITE);
}

void setEditFont(HWND h) {
    HFONT f = CreateFont(16, 0, 0, 0, FW_NORMAL, 0, 0, 0,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    SendMessage(h, WM_SETFONT, (WPARAM)f, 1);
}

void setLabelFont(HWND h) {
    HFONT f = CreateFont(18, 0, 0, 0, FW_BOLD, 0, 0, 0,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Microsoft YaHei UI");
    SendMessage(h, WM_SETFONT, (WPARAM)f, 1);
}

void setBtnFont(HWND h) {
    HFONT f = CreateFont(18, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Microsoft YaHei UI");
    SendMessage(h, WM_SETFONT, (WPARAM)f, 1);
}

void setStatusText(const char* msg) {
    SetWindowText(hStatus, msg);
}

// ========== ���Ƶ������� ==========
void copyToClipboard(const string& txt, const char* tip) {
    if (txt.empty()) {
        MessageBox(0, "����Ϊ�գ����踴��", "��ʾ", MB_ICONINFORMATION);
        return;
    }
    if (OpenClipboard(NULL)) {
        EmptyClipboard();
        HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, txt.size() + 1);
        if (hMem) {
            char* p = (char*)GlobalLock(hMem);
            memcpy(p, txt.c_str(), txt.size() + 1);
            GlobalUnlock(hMem);
            SetClipboardData(CF_TEXT, hMem);
        }
        CloseClipboard();
        setStatusText(tip);
    }
}

// ========== �������� ==========
void gen() {
    genKey();
    SetWindowText(hPub, bin2base64(pubKey).c_str());
    SetWindowText(hPriv, bin2base64(privKey).c_str());
    SetWindowText(hOut, "");
    setStatusText("��Կ���ɳɹ�");
}

void enc() {
    if (privKey.empty()) {
        setStatusText("����������Կ");
        return;
    }
    char buf[4096] = {0};
    GetWindowText(hIn, buf, 4095);
    string input = buf;
    if (input.empty() || input == "�ڴ�����Ҫ���ܵ�����...") {
        setStatusText("������Ҫ���ܵ�����");
        return;
    }
    auto c = encrypt(strToBin(input));
    SetWindowText(hOut, bin2base64(c).c_str());
    setStatusText("�������");
}

void dec() {
    if (privKey.empty()) {
        setStatusText("����������Կ");
        return;
    }
    char buf[4096] = {0};
    GetWindowText(hIn, buf, 4095);
    string input = buf;
    if (input.empty() || input == "�ڴ�����Ҫ���ܵ�����..." || input == "�ڴ�ճ������...") {
        setStatusText("������Ҫ���ܵ�����");
        return;
    }
    auto m = decrypt(base642bin(input));
    if (m.empty()) {
        setStatusText("����ʧ�ܣ��������ĸ�ʽ");
    } else {
        SetWindowText(hOut, binToStr(m).c_str());
        setStatusText("�������");
    }
}

void copyPubKey() {
    char buf[4096] = {0};
    GetWindowText(hPub, buf, 4095);
    copyToClipboard(buf, "��Կ�Ѹ���");
}

void copyPrivKey() {
    char buf[4096] = {0};
    GetWindowText(hPriv, buf, 4095);
    copyToClipboard(buf, "˽Կ�Ѹ���");
}

void copyResult() {
    char buf[4096] = {0};
    GetWindowText(hOut, buf, 4095);
    copyToClipboard(buf, "����Ѹ���");
}

void save() {
    char p[2048] = {0}, v[2048] = {0}, o[4096] = {0};
    GetWindowText(hPub, p, 2047);
    GetWindowText(hPriv, v, 2047);
    GetWindowText(hOut, o, 4095);
    
    OPENFILENAME ofn = {0};
    char file[MAX_PATH] = "result.txt";
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = GetParent(hPub);
    ofn.lpstrFilter = "�ı��ļ�\0*.txt\0�����ļ�\0*.*\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "txt";
    ofn.Flags = OFN_OVERWRITEPROMPT;
    
    if (GetSaveFileName(&ofn)) {
        ofstream f(file);
        f << "===== McEliece �����Ӽ��� =====\n";
        f << "��Կ:\n" << p << "\n\n";
        f << "˽Կ:\n" << v << "\n\n";
        f << "����:\n" << o << "\n";
        f.close();
        string msg = "�ѱ����� ";
        msg += file;
        setStatusText(msg.c_str());
    }
}

// ========== ���������� ==========
HWND createSectionLabel(HWND parent, const char* title, int x, int y, int w, int h) {
    HWND label = CreateWindow("STATIC", title, WS_CHILD | WS_VISIBLE,
        x, y, w, h, parent, NULL, 0, NULL);
    setLabelFont(label);
    return label;
}

// ========== ���ڹ��� ==========
LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch(m) {
    case WM_CREATE: {
        // ������ˢ
        hBgBrush = CreateSolidBrush(COLOR_BG);
        hWhiteBrush = CreateSolidBrush(COLOR_WHITE);
        
        int x = 20, y = 16;
        int panelW = 810;
        
        // ===== ��Կ���� =====
        createSectionLabel(h, "��Կ����", x, y, 200, 28);
        y += 32;
        
        // ��Կ��
        CreateWindow("STATIC", "��Կ", WS_CHILD|WS_VISIBLE,
            x, y+4, 40, 22, h, NULL, 0, NULL);
        setLabelFont(GetDlgItem(h, 0));  // �򻯣���Ӱ�칦��
        
        hPub = CreateWindow("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL|ES_READONLY,
            x+50, y, 630, 28, h, NULL, 0, NULL);
        styleEdit(hPub);
        setEditFont(hPub);
        
        CreateWindow("BUTTON", "����", WS_CHILD|WS_VISIBLE,
            x+690, y, 100, 28, h, (HMENU)ID_COPY_PUB, 0, NULL);
        setBtnFont(GetDlgItem(h, ID_COPY_PUB));
        
        y += 36;
        
        // ˽Կ��
        CreateWindow("STATIC", "˽Կ", WS_CHILD|WS_VISIBLE,
            x, y+4, 40, 22, h, NULL, 0, NULL);
        
        hPriv = CreateWindow("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL|ES_READONLY,
            x+50, y, 630, 28, h, NULL, 0, NULL);
        styleEdit(hPriv);
        setEditFont(hPriv);
        
        CreateWindow("BUTTON", "����", WS_CHILD|WS_VISIBLE,
            x+690, y, 100, 28, h, (HMENU)ID_COPY_PRIV, 0, NULL);
        setBtnFont(GetDlgItem(h, ID_COPY_PRIV));
        
        y += 50;
        
        // ===== ��ť���� =====
        int bx = x, bw = 185, bh = 42;
        
        HWND b1 = CreateWindow("BUTTON", "������Կ", WS_CHILD|WS_VISIBLE,
            bx, y, bw, bh, h, (HMENU)ID_GEN_KEY, 0, NULL);
        setBtnFont(b1);
        
        bx += bw + 15;
        HWND b2 = CreateWindow("BUTTON", "��  ��", WS_CHILD|WS_VISIBLE,
            bx, y, bw, bh, h, (HMENU)ID_ENCRYPT, 0, NULL);
        setBtnFont(b2);
        
        bx += bw + 15;
        HWND b3 = CreateWindow("BUTTON", "��  ��", WS_CHILD|WS_VISIBLE,
            bx, y, bw, bh, h, (HMENU)ID_DECRYPT, 0, NULL);
        setBtnFont(b3);
        
        bx += bw + 15;
        HWND b4 = CreateWindow("BUTTON", "�����ļ�", WS_CHILD|WS_VISIBLE,
            bx, y, bw, bh, h, (HMENU)ID_SAVE, 0, NULL);
        setBtnFont(b4);
        
        y += 56;
        
        // ===== �������� =====
        createSectionLabel(h, "��������", x, y, 200, 28);
        y += 32;
        
        hIn = CreateWindow("EDIT", "�ڴ�����Ҫ���ܵ�����...",
            WS_CHILD|WS_VISIBLE|WS_BORDER|ES_MULTILINE|ES_AUTOVSCROLL,
            x, y, panelW, 100, h, NULL, 0, NULL);
        styleEdit(hIn);
        setEditFont(hIn);
        
        y += 116;
        
        // ===== ������� =====
        createSectionLabel(h, "������", x, y, 200, 28);
        
        CreateWindow("BUTTON", "���ƽ��", WS_CHILD|WS_VISIBLE,
            x+700, y-2, 100, 26, h, (HMENU)ID_COPY_RESULT, 0, NULL);
        
        y += 32;
        
        hOut = CreateWindow("EDIT", "",
            WS_CHILD|WS_VISIBLE|WS_BORDER|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,
            x, y, panelW, 100, h, NULL, 0, NULL);
        styleEdit(hOut);
        setEditFont(hOut);
        
        y += 116;
        
        // ===== ״̬�� =====
        hStatus = CreateWindow("STATIC", "���� - ����������Կ",
            WS_CHILD|WS_VISIBLE|SS_CENTER,
            x, y, panelW, 26, h, NULL, 0, NULL);
        HFONT sf = CreateFont(15, 0, 0, 0, FW_NORMAL, 0, 0, 0,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Microsoft YaHei UI");
        SendMessage(hStatus, WM_SETFONT, (WPARAM)sf, 1);
        
        break;
    }
    
    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)w;
        SetBkColor(hdc, COLOR_WHITE);
        SetTextColor(hdc, COLOR_TEXT);
        return (LRESULT)hWhiteBrush;
    }
    
    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)w;
        HWND ctrl = (HWND)l;
        if (ctrl == hStatus) {
            SetBkColor(hdc, COLOR_BG);
            SetTextColor(hdc, COLOR_HINT);
            return (LRESULT)hBgBrush;
        }
        SetBkColor(hdc, COLOR_BG);
        SetTextColor(hdc, COLOR_TEXT);
        return (LRESULT)hBgBrush;
    }
    
    case WM_ERASEBKGND: {
        HDC hdc = (HDC)w;
        RECT rc;
        GetClientRect(h, &rc);
        FillRect(hdc, &rc, hBgBrush);
        return 1;
    }
    
    case WM_COMMAND:
        switch (LOWORD(w)) {
            case ID_GEN_KEY:    gen(); break;
            case ID_ENCRYPT:    enc(); break;
            case ID_DECRYPT:    dec(); break;
            case ID_SAVE:       save(); break;
            case ID_COPY_PUB:   copyPubKey(); break;
            case ID_COPY_PRIV:  copyPrivKey(); break;
            case ID_COPY_RESULT:copyResult(); break;
        }
        break;
        
    case WM_DESTROY:
        DeleteObject(hBgBrush);
        DeleteObject(hWhiteBrush);
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(h, m, w, l);
}

// ========== ������� ==========
int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR, int ns) {
    // ע�ᴰ����
    WNDCLASSEX wc = {sizeof(WNDCLASSEX)};
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hi;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "McElieceUI";
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    
    if (!RegisterClassEx(&wc)) return 1;
    
    // ���㴰�ھ���λ��
    int winW = 870, winH = 630;
    int winX = (GetSystemMetrics(SM_CXSCREEN) - winW) / 2;
    int winY = (GetSystemMetrics(SM_CYSCREEN) - winH) / 2;
    
    // ��������
    HWND hwnd = CreateWindowEx(0, "McElieceUI",
        "McEliece �����Ӽ��ܹ���",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        winX, winY, winW, winH, NULL, NULL, hi, NULL);
    
    if (!hwnd) return 1;
    
    ShowWindow(hwnd, ns);
    UpdateWindow(hwnd);
    
    // ��Ϣѭ��
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}
